import React, { createContext } from "react";

const InputContext = createContext(null)

export default InputContext
import Title from '/components/Title'

export default function Roma() {
    return (
        <Title tag='h3'>Como criar bots do discord do 0 conectados a outros aplicativos</Title>
    )
}
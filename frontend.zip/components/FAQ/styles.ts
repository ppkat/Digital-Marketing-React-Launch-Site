import styled from 'styled-components';

const Container = styled.div`
`;

export const StyledSummary = styled.summary`
    cursor: pointer;
    margin-top: 10%;
    font-weight: 700;
    list-style-type: none;
`

export default Container;
import styled from 'styled-components'

export const Container = styled.footer`
    margin-top: 4%;
    font-size: 10px;
    text-align: center;
`
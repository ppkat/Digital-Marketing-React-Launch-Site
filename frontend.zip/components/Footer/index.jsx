import { Container } from "./styles";

export default function Footer() {
    return (
        <Container>
            <p>João Pedro Gaspar Pereira - Todos os direitos reservados</p>
        </Container>
    )
}

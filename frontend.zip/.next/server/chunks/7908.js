"use strict";
exports.id = 7908;
exports.ids = [7908];
exports.modules = {

/***/ 6826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const InputContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputContext);


/***/ }),

/***/ 7908:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SubscriptionForm)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./Contexts/InputContext.js
var InputContext = __webpack_require__(6826);
// EXTERNAL MODULE: ./pages/inscrever/Sections/CallToAction/SubscriptionForm/styles.js
var styles = __webpack_require__(6083);
// EXTERNAL MODULE: external "validator/lib/isEmail"
var isEmail_ = __webpack_require__(7379);
var isEmail_default = /*#__PURE__*/__webpack_require__.n(isEmail_);
// EXTERNAL MODULE: ./components/CTAButton/index.jsx + 1 modules
var CTAButton = __webpack_require__(3096);
;// CONCATENATED MODULE: ./lib/emailListSubscribe.js
async function emailListSubscribe(email) {
    try {
        const res = await fetch("/api/emailList/subscribe", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email
            })
        });
        if (res.status === 400) throw new Error(`Status code error: ${res.status}`);
        const data = await res.json();
        return data.email;
    } catch (err) {
        console.log(err);
        throw err;
    }
}

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./pages/inscrever/Sections/CallToAction/SubscriptionForm/index.jsx








function SubscriptionForm() {
    const inputRef = (0,external_react_.useContext)(InputContext/* default */.Z);
    const router = (0,router_.useRouter)();
    const [err, setErr] = (0,external_react_.useState)(false);
    async function handleClick(e) {
        e.preventDefault();
        const email = inputRef.current ? inputRef.current.value : null;
        if (!isEmail_default()(email)) return setErr(true);
        emailListSubscribe(email).then(()=>router.push("/obrigado")).catch((err)=>setErr(true));
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(styles["default"], {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                ref: inputRef,
                type: "email",
                className: "textInput",
                placeholder: "Digite seu email aqui",
                autoFocus: true
            }),
            err ? /*#__PURE__*/ jsx_runtime_.jsx(styles.ErrorSpan, {
                children: "Digite um email v\xe1lido"
            }) : null,
            " ",
            /*#__PURE__*/ jsx_runtime_.jsx(CTAButton/* default */.Z, {
                href: "/obrigado",
                buttWidth: 100,
                onClick: handleClick,
                children: "Quero Participar"
            })
        ]
    });
}


/***/ })

};
;
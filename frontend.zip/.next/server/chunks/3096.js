"use strict";
exports.id = 3096;
exports.ids = [3096];
exports.modules = {

/***/ 3096:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_CTAButton)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./components/CTAButton/styles.js

const Container = external_styled_components_default().div.withConfig({
    componentId: "sc-ea9084e2-0"
})`
    padding: 0;
    margin: 0;
    width: ${(props)=>props.buttWidth}%;
`;
const StyledButton = external_styled_components_default().button.withConfig({
    componentId: "sc-ea9084e2-1"
})`
    min-width: 100%;
    background-color: #1445da;
    height: 80px;
    border-radius: 20px;
    border: none;
    font-size: 1em;
    font-size: 40px;
    
    :hover {
        background-color: #1157ec;
        cursor: pointer;
    }

    @media (max-width : 800px) {
        text-align: center;
        font-size: max(0.8em, 30px);
    }
`;

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/CTAButton/index.jsx



function CTAButton({ children , href , buttWidth , ...props }) {
    const Tag = href ? (link_default()) : "div";
    buttWidth = buttWidth ?? 80;
    return /*#__PURE__*/ jsx_runtime_.jsx(Container, {
        buttWidth: buttWidth,
        children: href ? /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
            href: href,
            children: /*#__PURE__*/ jsx_runtime_.jsx(StyledButton, {
                ...props,
                children: children
            })
        }) : /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(StyledButton, {
                ...props,
                children: children
            })
        })
    });
}
/* harmony default export */ const components_CTAButton = (CTAButton);


/***/ })

};
;
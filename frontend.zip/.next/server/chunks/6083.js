"use strict";
exports.id = 6083;
exports.ids = [6083];
exports.modules = {

/***/ 6083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmailsAdvertising": () => (/* binding */ EmailsAdvertising),
/* harmony export */   "ErrorSpan": () => (/* binding */ ErrorSpan),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Form = styled_components__WEBPACK_IMPORTED_MODULE_0___default().form.withConfig({
    componentId: "sc-e48321a5-0"
})`
        width: 80%;
        display: flex;
        align-items: center;
        flex-direction: column;
        font-size: 40px;

        .textInput {
            width: 100%;
            height: 80px;
            background-color: white;
            padding: 20px;
            font-size: 1em;
            border-radius: 20px;
            color: black;
            margin-bottom: 10px;
            @media (max-width : 800px) {
                text-align: center;
                font-size: 0.5em;
            }
        }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);
const ErrorSpan = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
    componentId: "sc-e48321a5-1"
})`
    font-size: 20px;
    color: #ff2020;
    margin-bottom: 10px;
`;
const EmailsAdvertising = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
    componentId: "sc-e48321a5-2"
})`
    font-size: max(0.7vw, 7px);
    text-align: justify;
    display: flex;
    flex-direction: column;

    span {
        margin: 5px 0;
        font-size: max(1vw, 10px);
        display: flex;
        align-items: center;

        input {
            margin-right: min(0.8vw, 10px);
        }
    }
`;


/***/ })

};
;
"use strict";
exports.id = 6710;
exports.ids = [6710];
exports.modules = {

/***/ 6710:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Title)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./components/Title/styles.js

const Container = external_styled_components_default().div.withConfig({
    componentId: "sc-6a7c57d0-0"
})`
    font-size: max(${(props)=>props.fontSizeMin}, ${(props)=>props.fontSizeRelative});
    color: ${(props)=>props.color};
    text-align: ${(props)=>props.align};
`;
/* harmony default export */ const styles = (Container);

;// CONCATENATED MODULE: ./components/Title/index.jsx


function Title({ tag ="h1" , color ="white" , align ="center" , children  }) {
    const hNum = Number(tag.slice(-1)) // the last number of "h" tags
    ;
    const fontSize = ()=>{
        let fontVw = 2.6;
        let fontPx = 18;
        for(let i = hNum; i > 1; i--){
            fontVw -= 0.45;
        }
        return {
            relative: String(fontVw) + "vw",
            min: String(fontPx) + "px"
        };
    };
    const Tag = tag;
    return /*#__PURE__*/ jsx_runtime_.jsx(styles, {
        color: color,
        align: align,
        fontSizeRelative: fontSize().relative,
        fontSizeMin: fontSize().min,
        children: /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
            children: children
        })
    });
}


/***/ })

};
;
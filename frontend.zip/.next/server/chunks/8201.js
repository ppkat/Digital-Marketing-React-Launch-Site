"use strict";
exports.id = 8201;
exports.ids = [8201];
exports.modules = {

/***/ 8201:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Authority)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1259);
/* harmony import */ var _components_Title__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6710);



function Authority() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_1__["default"], {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Title__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                tag: "h2",
                color: "#0d60dd",
                align: "left",
                children: "Quem \xe9 Jo\xe3o Pedro?"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                children: "Jo\xe3o Pedro \xe9 um desenvovedor que depois de criar diversos tipos de bots do discord e at\xe9 trabalhar com isso, se apaixonou por este mundo do desenvolvimento, ficando sempre maravilhado com as infinitas possibilidades existentes de comandos e funcionalidades diferentes que podem ser criados. Para poder ver mais este mundo de bots do discord crescer, decidiu ajudar outros usu\xe1rios do discord a desenvolverem seus pr\xf3prios bots que se conectam \xe0 sites e aplicativos da web para poder ampliar cada vez mais a diversidade no discord, e trazer mais pessoas para esse universo incr\xedvel da tecnologia."
            })
        ]
    });
}


/***/ }),

/***/ 1259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_BaseSection_jsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9780);


const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_styles_BaseSection_jsx__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z).withConfig({
    componentId: "sc-278e32dd-0"
})`
    text-align: justify;
    font-size: max(25px, 2.2vw);
    background-image: url('/images/banner_jp.png');
    background-repeat: no-repeat;
    background-position-x: 100%;
    background-size: cover;

    p{
        font-size: max(25px, 1.8vw);
        color: white;
    }

    @media (max-width: 1200px) {
        background-image: url('/images/background_medium.png');
    }
    
    @media (max-width: 550px) {
        background-image: url('/images/background_small.png');
    }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);


/***/ })

};
;
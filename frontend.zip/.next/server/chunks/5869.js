"use strict";
exports.id = 5869;
exports.ids = [5869];
exports.modules = {

/***/ 5869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeliverablesCollum": () => (/* binding */ DeliverablesCollum),
/* harmony export */   "DeliverablesRow": () => (/* binding */ DeliverablesRow),
/* harmony export */   "Title": () => (/* binding */ Title),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_BaseSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9780);


const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_styles_BaseSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z).withConfig({
    componentId: "sc-f9142bd1-0"
})`
    margin-top: 10%;
    padding: 0 15%;

    @media (max-width: 800px) {
        padding: 0 10px;
    }

    p{
        font-size: max(16px, 1.3vw);
    }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);
const Title = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h2.withConfig({
    componentId: "sc-f9142bd1-1"
})`
    text-align: center;
    font-size: max(25px, 3.0vw);
`;
const DeliverablesRow = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-f9142bd1-2"
})`
    display: flex;
    flex-direction: row;
    height: 50%;

    @media (max-width: 800px) {
        flex-direction: column;
        justify-content: space-evenly;
    }
`;
const DeliverablesCollum = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-f9142bd1-3"
})`
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    min-height: 40vh;

    @media (max-width: 800px) {
        height: 90vh;
    }
`;


/***/ })

};
;
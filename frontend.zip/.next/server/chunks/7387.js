"use strict";
exports.id = 7387;
exports.ids = [7387];
exports.modules = {

/***/ 7387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventDescription": () => (/* binding */ EventDescription),
/* harmony export */   "ImageContainer": () => (/* binding */ ImageContainer),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_BaseSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9780);


const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_styles_BaseSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z).withConfig({
    componentId: "sc-a1640623-0"
})`
    margin-top: 10vh;
    width: 100%;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 0 15%;

    @media (max-width: 800px) {
        padding: 0 10px;
        flex-direction: column;
        align-items: center;
    }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);
const EventDescription = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-a1640623-1"
})`
    margin-left: 10vw;

    p {
        font-size: max(16px, 1.3vw);
        text-align: justify;
    }
    
    @media (max-width: 800px) {
        margin-left: 0;
        margin-top: 5vh;

        h2 {
            text-align: center;
        }
    }
`;
const ImageContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-a1640623-2"
})`
    display: flex;
    flex-direction: row;
    align-items: center;
    max-width: 40%;
    
    img {
        border-radius: 100%;
    }

    @media (max-width: 800px) {
        max-width: min(50%, 280px);
    }
`;


/***/ }),

/***/ 9780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const BaseSection = styled_components__WEBPACK_IMPORTED_MODULE_0___default().section.withConfig({
    componentId: "sc-292c793c-0"
})`
    margin-top: 10%;
    padding: 3% 15%;
    display: flex;
    flex-direction: column;
    align-items: center;

    @media (max-width: 800px) {
        padding: 2% 10px;
    }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BaseSection);


/***/ })

};
;
"use strict";
exports.id = 1057;
exports.ids = [1057];
exports.modules = {

/***/ 1057:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ EventTimer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./pages/obrigado/Sections/EventTimer/styles.js
var styles = __webpack_require__(626);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./components/Timer/NumberSquare/styles.js

const Container = external_styled_components_default().div.withConfig({
    componentId: "sc-1f71096b-0"
})`
    display: flex;
    flex-direction: row;
    align-items: center;
`;
const SquareDiv = external_styled_components_default().div.withConfig({
    componentId: "sc-1f71096b-1"
})`
    background-color: #3577f1;
    text-align: center;
    vertical-align: middle;
    line-height: max(45px, 4.5vw); 
    min-width: max(40px, 4vw);
    min-height: max(45px, 4.5vw);
    border-radius: 10%;
    font-size: max(18px, 2.2vw);
    font-weight: bold;
`;

;// CONCATENATED MODULE: ./components/Timer/NumberSquare/index.jsx


function NumberSquare({ value  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Container, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(SquareDiv, {
            children: value
        })
    });
}

;// CONCATENATED MODULE: ./components/Timer/styles.js

const styles_Container = external_styled_components_default().div.withConfig({
    componentId: "sc-f5b06fde-0"
})`
    display: flex;
    justify-content: space-between;
`;
const SquareWithText = external_styled_components_default().div.withConfig({
    componentId: "sc-f5b06fde-1"
})`
    display: flex;
    flex-direction: column;
    align-items: center;
    font-size: max(8px, 0.8vw);

    margin-left: 15px;

    @media (max-width: 800px) {
        margin-left: 5px;
    }
`;

;// CONCATENATED MODULE: ./components/Timer/index.jsx




function Timer({ date  }) {
    const [currentDate, setCurrentDate] = (0,external_react_.useState)(date);
    (0,external_react_.useEffect)(()=>{
        setCurrentDate(new Date());
        const intervalId = setInterval(()=>{
            setCurrentDate(new Date());
        }, 1000);
        return ()=>clearInterval(intervalId);
    }, []);
    const formatNumber = (number)=>number.toString().padStart(2, "0");
    const timeLeft = date - currentDate;
    const days = formatNumber(Math.floor(timeLeft / (1000 * 60 * 60 * 24)));
    const hours = formatNumber(Math.floor(timeLeft % (1000 * 60 * 60 * 24) / (1000 * 60 * 60)));
    const minutes = formatNumber(Math.floor(timeLeft % (1000 * 60 * 60) / (1000 * 60)));
    const seconds = formatNumber(Math.floor(timeLeft % (1000 * 60) / 1000));
    const timeTypes = [
        days,
        hours,
        minutes,
        seconds
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(styles_Container, {
        children: timeTypes.map((timePiece, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(SquareWithText, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(NumberSquare, {
                        value: timePiece
                    }),
                    i === 0 ? "DIAS" : i === 1 ? "HORAS" : i === 2 ? "MINUTOS" : "SEGUNDOS"
                ]
            }, i))
    });
}

;// CONCATENATED MODULE: ./pages/obrigado/Sections/EventTimer/index.jsx



function EventTimer() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(styles["default"], {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(styles.EventNameContainer, {
                children: "\uD835\uDD40Ꭰ\xda\uD835\uDCE2\uD835\uDD4B\uD835\uDCE1ιᴀ \uD835\uDE3F0 B\uD835\uDC0E\uD835\uDE1B"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Timer, {
                date: new Date(2023, 1, 1, 20)
            })
        ]
    });
}


/***/ }),

/***/ 626:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventNameContainer": () => (/* binding */ EventNameContainer),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_BaseSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9780);


const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_styles_BaseSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z).withConfig({
    componentId: "sc-542a89f5-0"
})`
    margin-top: 10px;
    flex-direction: row;
    justify-content: space-between;
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);
const EventNameContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-542a89f5-1"
})`
    padding-left: 5%;
    font-size: max(22px, 2.3vw);
    text-align: center;
    max-width: 40%;

    @media (max-width: 800px) {
    }
`;


/***/ }),

/***/ 9780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const BaseSection = styled_components__WEBPACK_IMPORTED_MODULE_0___default().section.withConfig({
    componentId: "sc-292c793c-0"
})`
    margin-top: 10%;
    padding: 3% 15%;
    display: flex;
    flex-direction: column;
    align-items: center;

    @media (max-width: 800px) {
        padding: 2% 10px;
    }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BaseSection);


/***/ })

};
;
"use strict";
exports.id = 5783;
exports.ids = [5783];
exports.modules = {

/***/ 5783:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ EventDeliverables)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5869);
/* harmony import */ var _Deliverable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);



function EventDeliverables() {
    class Delivery {
        constructor({ src , alt , title , text  }){
            this.src = src;
            this.alt = alt;
            this.title = title;
            this.text = text;
        }
    }
    const Deliveries = [
        new Delivery({
            src: "/images/youtube-logo-icon-transparent---32.webp",
            alt: "Logo do Youtube",
            title: "Aula ao vivo",
            text: "O evento vai contar um uma aula ao vivo para ensinar o passo para passo a criar bots do discord que se conectam com sites."
        }),
        new Delivery({
            src: "/images/discord_chat1.webp",
            alt: "Logo do Discord",
            title: "Servidor do Discord",
            text: "Durante o evento voc\xea ter\xe1 acesso a um servidor exclusivo do discord, onde poder\xe1 usar para pedir ajuda para desenvolver o bot, conversar com outros participantes, receber as informa\xe7\xf5es de acesso ao evento e at\xe9 poder ver os testes do bot funcionando ao vivo no dia do evento"
        }),
        new Delivery({
            src: "/images/bot_icon.webp",
            alt: "icone ilustrativo de um bot do discord",
            title: "Bot feito do zero",
            text: "Na aula vamos criar juntos um bot do discord que se conecta \xe0 um site de fontes de internet, mesmo que voc\xea n\xe3o saiba nada de programa\xe7\xe3o. Ao final tamb\xe9m ser\xe1 disponibilizado o c\xf3digo fonte do bot, para que voc\xea n\xe3o perca nada."
        }),
        new Delivery({
            src: "/images/questionMark.webp",
            alt: "interroga\xe7\xe3o com estilo de mario",
            title: "Tira d\xfavidas",
            text: "Teremos ao final da aula um tempo espec\xedfico para que voc\xea mande suas d\xfavidas e elas possam ser respondidas ao vivo"
        })
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_1__["default"], {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_1__.Title, {
                children: "Entreg\xe1veis do evento"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_1__.DeliverablesCollum, {
                children: Deliveries.map((delivery, i, arr)=>(i + 1) % 2 !== 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_1__.DeliverablesRow, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Deliverable__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                src: delivery.src,
                                alt: delivery.alt,
                                title: delivery.title,
                                text: delivery.text
                            }),
                            arr[i + 1] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Deliverable__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                src: arr[i + 1].src,
                                alt: arr[i + 1].alt,
                                title: arr[i + 1].title,
                                text: arr[i + 1].text
                            }) : null
                        ]
                    }, i) : null)
            })
        ]
    });
}


/***/ })

};
;
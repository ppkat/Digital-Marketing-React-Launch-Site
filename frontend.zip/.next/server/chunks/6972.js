"use strict";
exports.id = 6972;
exports.ids = [6972];
exports.modules = {

/***/ 6972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Icon)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./components/Icon/styles.js

const ImageContainer = external_styled_components_default().div.withConfig({
    componentId: "sc-483cf4ff-0"
})`
    display: flex;
    flex-direction: row;
    align-items: center;
    max-width: ${(props)=>props.size ?? 20}%;
    margin-right: 10px;
    
    img {
        border-radius: 100%;
    }

    @media (max-width: 800px) {
        max-width: min(${(props)=>props.size ?? 20}%, 50px);
    }
`;

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Icon/index.jsx



function Icon({ src , alt , size  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(ImageContainer, {
        size: size,
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: src,
            alt: alt,
            width: 100,
            height: 100,
            layout: "responsive"
        })
    });
}


/***/ })

};
;
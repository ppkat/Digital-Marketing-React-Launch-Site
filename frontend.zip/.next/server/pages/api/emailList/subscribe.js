"use strict";
(() => {
var exports = {};
exports.id = 6289;
exports.ids = [6289];
exports.modules = {

/***/ 5142:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 2666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ emailInscribe)
});

;// CONCATENATED MODULE: external "validator/lib/isEmail"
const isEmail_namespaceObject = require("validator/lib/isEmail");
var isEmail_default = /*#__PURE__*/__webpack_require__.n(isEmail_namespaceObject);
// EXTERNAL MODULE: external "dotenv"
var external_dotenv_ = __webpack_require__(5142);
;// CONCATENATED MODULE: ./pages/api/emailList/subscribe.ts


(0,external_dotenv_.config)();
//sorry for putting typescript on middle of application, but i can't work without it anymore ;D
async function emailInscribe(req, res) {
    const email = req.body.email;
    if (!email) {
        return res.status(400).json({
            message: "Email \xe9 obrigat\xf3rio"
        });
    }
    if (!isEmail_default()(email)) {
        return res.status(400).json({
            message: "Email inv\xe1lido"
        });
    }
    try {
        const response = await fetch("https://connect.mailerlite.com/api/subscribers", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": `Bearer ${process.env.API_TOKEN}`
            },
            body: JSON.stringify({
                email: email
            })
        });
        if (!response.ok) {
            throw new Error("Falha na inscri\xe7\xe3o");
        }
        return res.status(200).json({
            message: "Inscri\xe7\xe3o realizada com sucesso"
        });
    } catch (error) {
        return res.status(500).json({
            message: "Erro interno"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2666));
module.exports = __webpack_exports__;

})();
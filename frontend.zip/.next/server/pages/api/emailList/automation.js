"use strict";
(() => {
var exports = {};
exports.id = 701;
exports.ids = [701];
exports.modules = {

/***/ 5142:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 4697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ webHooksListeners)
});

;// CONCATENATED MODULE: external "crypto"
const external_crypto_namespaceObject = require("crypto");
var external_crypto_default = /*#__PURE__*/__webpack_require__.n(external_crypto_namespaceObject);
// EXTERNAL MODULE: external "dotenv"
var external_dotenv_ = __webpack_require__(5142);
;// CONCATENATED MODULE: ./pages/api/emailList/automation.ts


(0,external_dotenv_.config)();
function webHooksListeners(req, res) {
    if (!req.headers["Signature"]) return res.status(401).end();
    if (!req.body) return res.status(400).end();
    const signature = req.headers["Signature"].toString();
    console.log(signature);
    // Create a hash using the request body and the secret key
    const hash = external_crypto_default().createHmac("sha256", process.env.API_TOKEN).update(JSON.stringify(req.body)).digest("hex");
    if (signature !== hash) return res.status(401).end();
    const newSubscriber = req.body;
    console.log(newSubscriber);
    return res.status(200).json(newSubscriber);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4697));
module.exports = __webpack_exports__;

})();
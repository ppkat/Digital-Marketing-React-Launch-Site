import { Client } from 'ssh2';
const conn = new Client();
conn.on('ready', function () {
    console.log('Client :: ready');
    conn.exec('mkdir -p ~/test-app', function (err, stream) {
        if (err) throw err;
        stream.on('close', function (code, signal) {
            console.log('Stream :: close :: code: ' + code + ', signal: ' + signal);
            conn.end();
        }).on('data', function (data) {
            console.log('STDOUT: ' + data);
        }).stderr.on('data', function (data) {
            console.log('STDERR: ' + data);
        });
    });
}).connect({
    host: '192.168.100.100',
    port: 22,
    username: 'username',
    password: 'password'
});